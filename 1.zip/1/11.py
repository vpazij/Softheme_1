# -*- coding: utf-8 -*-

f = open('input.txt')
x = f.read()
f.close()
global b
a=0
b=0
for i in x:
	#print(i)
	if i=="1":
		
		a+=1
		if a>b:
			b=a
	else:
		a=0
#print (b)
f = open('output.txt', 'w')
f.write(str(b))
f.close()
		
	
		
